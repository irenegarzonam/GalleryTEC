var searchData=
[
  ['metadata_0',['MetaData',['../class_meta_data.html',1,'']]],
  ['mongodbhandler_1',['MongoDbHandler',['../classlearning_1_1_mongo_db_handler.html',1,'learning']]]
];
