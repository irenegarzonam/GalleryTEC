var searchData=
[
  ['genparity_0',['GenParity',['../class_raid5.html#ab0ce6169ebad6dc65ad989580bf63638',1,'Raid5::GenParity(vector&lt; string &gt; stPaths)'],['../class_raid5.html#ae157a07b3c1dc4d6f393d364af335d0b',1,'Raid5::GenParity(vector&lt; string &gt; stPaths, int parity4file, int doc4file)']]],
  ['getalldatafromdb_1',['GetAllDataFromDb',['../classlearning_1_1_mongo_db_handler.html#a9120347140c287d3a6bbdb9d8964723b',1,'learning::MongoDbHandler']]]
];
