var searchData=
[
  ['kmongodburi_0',['kMongoDbUri',['../mongodb__handler_8h.html#a069d4d44c8820a6bb4bd6dd208db6de1',1,'learning']]]
];
