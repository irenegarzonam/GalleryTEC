var searchData=
[
  ['mongodbhandler_0',['MongoDbHandler',['../classlearning_1_1_mongo_db_handler.html#ab65f2fc87c8798bf8bf3b2a76fd86554',1,'learning::MongoDbHandler']]]
];
